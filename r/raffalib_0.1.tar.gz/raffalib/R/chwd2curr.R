#!/usr/bin/env R

#' CWD to current file's dir
#'
#' Change the current working directory 
#' to the directory in which the script we are running resides.
#'
#' @param fnc A function that takes no argument and returns nothing (\code{function(){}})
#' @param cont Pass \code{rstudioapi::getActiveDocumentContext()} or \code{NULL}
#' 
#' @return None
#'
#' @examples
#' library(rstudioapi)
#' invisible(chwd2curr(function(){}, rstudioapi::getActiveDocumentContext()))
#'
#' @export
chwd2curr <- function(fnc, cont) {
	# Change WD to current file
	# - source and knit
	srcdir <- getSrcDirectory(fnc)[1]
	if (srcdir != "") {
		print("Using getSrcDirectory")
	}
	else {
		# - run
		print("Using rstudioapi")
		srcdir <- dirname(cont$path)
	}
	setwd(srcdir)
	print(paste0("Working directory changed to: ", srcdir))
	return(srcdir)
}
